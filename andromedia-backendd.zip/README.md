# Andromedia Backend

Public backend server for Andromeda Blog.

## Run locally

npm install
npm start

Server runs on http://localhost:3000
